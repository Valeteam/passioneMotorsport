<?php

session_start();


$ruolo = $_SESSION['ruolo'];

require_once '../psmrt_new/php/config.php';

$ultimeNews = fetchAllQuery($pdo, "
    SELECT news.*, categorie.nome AS categoria
    FROM news
    LEFT JOIN categorie ON news.categoria_id = categorie.id
    ORDER BY data_pubblicazione DESC
    LIMIT 6
");

$sponsorAttivi = fetchAllQuery($pdo, "
    SELECT * FROM sponsor ORDER BY nome ASC
");

$calendario = fetchAllQuery($pdo, "
    SELECT * FROM calendario ORDER BY stato DESC
    LIMIT 20
");

$gareReali = array_filter($calendario, fn($gara) => $gara['reparto'] === 'reale');
$gareEsports = array_filter($calendario, fn($gara) => $gara['reparto'] === 'esports');
function classeStato($stato)
{
    if ($stato === 'disputata') return 'done';
    if ($stato === 'prossima') return 'during';
    return 'program';
}

?>


<!DOCTYPE html>
<html lang="ita">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Passione Motorsport</title>

    <link rel="icon" type="image/png" sizes="16x16" href="assets/img/logo/logo.png">
    <link rel="icon" type="image/png" sizes="32x32" href="assets/img/logo/logo.png">
    <link rel="icon" type="image/x-icon" href="assets/img/logo/logo.png">


    <link rel="stylesheet" href="css/components/navbar.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/components/footer.css">
    <link rel="stylesheet" href="css/components/responsive.css">

</head>

<body>

    <!-- navBar -->

    <nav>
        <h2>Passione <span>Motorsport</span> Team</h2>
        <button class="nav-toggle" aria-label="Apri menu">
            ☰
        </button>
        <div class="nav-links">
            <a href="#home" id="homes" aria-current="page">home</a>
            <a href="#about" id="abouts">chi siamo</a>
            <a href="#news" id="newss">news</a>
            <a href="#calendario" id="calendarios">calendario</a>
            <a href="#sponsor" id="sponsors">sponsor</a>
            <a href="#virtualTeam" id="virtualTeams">Team Virtuale</a>
            <a href="#contatti" id="contattis">contatti</a>
            <a href="#contatti" class="headerCTA" id="headerCTAin">Entra nel Team</a>
        </div>
        <a href="#PremiumAccess" class="headerCTA">Entra nel Team</a>
    </nav>

    <!-- home -->

    <section class="home" id="home">
        <svg class="home-route" width="100%" height="420" viewBox="0 0 1120 420" preserveAspectRatio="none" role="img"
            aria-hidden="true">
            <path d="M -20 380 C 200 380, 260 120, 480 140 C 640 155, 660 300, 840 280 C 980 265, 1000 60, 1160 60"
                fill="none" stroke="rgb(202, 155, 68)" stroke-opacity="1.5" stroke-width="2" stroke-dasharray="10 8" />
        </svg>
        <svg class="home-route2" width="100%" height="420" viewBox="0 0 1120 420" preserveAspectRatio="none" role="img"
            aria-hidden="true">
            <path d="M -20 380 C 200 380, 260 120, 480 140 C 640 155, 660 300, 840 280 C 980 265, 1000 60, 1160 60"
                fill="none" stroke="rgb(202, 155, 68)" stroke-opacity="1" stroke-width="2" stroke-dasharray="10 8" />
        </svg>
        <div class="wrap">
            <h2 class="lineeta upper"> WRC ・ ERC ・ Gare Italiane - <span>Vivi la velocità ・ Condividi
                    l'adrenalina</span></h2>
            <h1 class="introText">Passione Motorsport</h1>

            <div class="underText">
                <h3>
                    Passione Motorsport è una community dedicata agli amanti delle competizioni automobilistiche.<br>
                    Organizziamo eventi online, seguiamo i principali campionati, raccontiamo il motorsport e <br>
                    offriamo a tutti la possibilità di entrare a far parte di un team unito dalla stessa passione.
                </h3>
            </div>

            <div class="hero-actions">
                <a href="#news" class="btn primary">ultime news</a>
                <a href="#contatti" class="btn ghost">contatti</a>
            </div>

        </div>
    </section>

    <!-- chiSiamo/About -->

    <section class="about" id="about">
        <h1>Chi siamo</h1>
        <h3>
            Passione Motorsport nasce dall'incontro di persone accomunate dall'amore per i motori, <br>
            la velocità e la competizione. Il nostro obiettivo è creare una realtà in cui piloti, appassionati,<br>
            fotografi, meccanici e sostenitori possano condividere esperienze, eventi e momenti indimenticabili. <br>
            <br>
            Crediamo che il motorsport non sia solo una disciplina sportiva, ma uno stile di vita fatto di sacrificio,
            <br>
            tecnica, emozioni e lavoro di squadra. <br>
        </h3>
        <div class="cards-grid">
            <div class="info-card">
                <p class="card-title">i nostri obiettivi</p>
                <ul class="info-list">
                    <li>Promuovere la cultura del motorsport</li>
                    <li class="accent">Organizzare e partecipare a eventi sportivi</li>
                    <li>Supportare giovani talenti</li>
                    <li class="accent chiusura">Creare una community inclusiva</li>
                </ul>
            </div>

            <div class="info-card">
                <p class="card-title">i nostri valori</p>
                <ul class="info-list">
                    <li>Passione</li>
                    <li class="accent">Professionalità</li>
                    <li>Spirito di squadra</li>
                    <li class="accent">Sicurezza</li>
                    <li class="chiusura">Innovazione</li>
                </ul>
            </div>
        </div>
    </section>

    <!-- news -->

    <section class="news" id="news">
        <div class="news-container">

            <div class="news-header">
                <h1 class="news-eyebrow">news</h1>
                <h2 class="news-heading">ultime notizie</h2>
            </div>

            <div class="news-category-filter">
                <button class="news-filter-btn active" data-filter="tutte">tutte</button>
                <button class="news-filter-btn" data-filter="gare">gare</button>
                <button class="news-filter-btn" data-filter="community">community</button>
                <button class="news-filter-btn" data-filter="annunci">annunci</button>
            </div>


            <?php foreach ($ultimeNews as $articolo): ?>
                <?php if ($articolo['in_evidenza'] === '1'): ?>
                    <article class="news-article-card"
                        data-id="<?php echo $articolo['id']; ?>"
                        data-category="<?php echo htmlspecialchars($articolo['categoria']); ?>"
                        data-date="<?php echo $articolo['data_pubblicazione']; ?>">
                        <img class="news-highlight-image" src="<?php echo htmlspecialchars($articolo['immagine']); ?>" alt="" loading="lazy">
                        <div class="news-highlight-content">
                            <div class="news-item-meta">
                                <span class="news-item-tag"><?php echo htmlspecialchars($articolo['categoria']); ?></span>
                                <span class="news-item-date"><?php echo htmlspecialchars($articolo['data_pubblicazione']); ?></span>
                            </div>
                            <h3 class="news-highlight-title"><?php echo htmlspecialchars($articolo['titolo']); ?></h3>
                            <p class="news-highlight-text"><?php echo htmlspecialchars($articolo['descrizione']); ?></p>
                            <a href="#" class="news-readmore-link">leggi tutto →</a>
                        </div>
                    </article>
                <?php endif; ?>
            <?php endforeach; ?>


            <div class="news-article-grid">
                <?php foreach ($ultimeNews as $articolo): ?>
                    <?php if ($articolo['in_evidenza'] !== '1'): ?>
                        <article class="news-article-card"
                            data-id="<?php echo $articolo['id']; ?>"
                            data-category="<?php echo htmlspecialchars($articolo['categoria']); ?>"
                            data-date="<?php echo $articolo['data_pubblicazione']; ?>">
                            <img class="news-card-image" src="<?php echo htmlspecialchars($articolo['immagine']); ?>" alt="" loading="lazy">
                            <div class="news-card-content">
                                <div class="news-item-meta">
                                    <span class="news-item-tag"><?php echo htmlspecialchars($articolo['categoria']); ?></span>
                                    <span class="news-item-date"><?php echo htmlspecialchars($articolo['data_pubblicazione']); ?></span>
                                </div>
                                <h4 class="news-card-title"><?php echo htmlspecialchars($articolo['titolo']); ?></h4>
                                <p class="news-card-text"><?php echo htmlspecialchars($articolo['descrizione']); ?></p>
                                <a href="#" class="news-readmore-link">leggi tutto →</a>
                            </div>
                        </article>
                    <?php endif; ?>
                <?php endforeach; ?>
            </div>
        </div>

        </div>
    </section>

    <!-- calendario -->

    <section class="calendario" id="calendario">
        <div class="realRace boxing">
            <h2>Calendario Gare Real Che Supportiamo</h2>
            <?php foreach ($gareReali as $realRace): ?>
                <h3 class="tag <?php echo classeStato($realRace['stato']); ?>">
                    <?php echo htmlspecialchars($realRace['nome']); ?>
                    <span><?php echo htmlspecialchars($realRace['data_gara']); ?></span>
                    <span><?php echo htmlspecialchars($realRace['stato']); ?></span>
                </h3>
            <?php endforeach; ?>
        </div>

        <div class="virtualRace boxing">
            <h2>Calendario Gare Virtuale</h2>
            <?php foreach ($gareEsports as $virtualRace): ?>
                <h3 class="tag <?php echo classeStato($virtualRace['stato']); ?>">
                    <?php echo htmlspecialchars($virtualRace['nome']); ?>
                    <span><?php echo htmlspecialchars($virtualRace['data_gara']); ?></span>
                    <span><?php echo htmlspecialchars($virtualRace['stato']); ?></span>
                </h3>
            <?php endforeach; ?>
        </div>
    </section>

    <!-- sponsor -->

    <section class="sponsor" id="sponsor">
        <h1>Sostenitori O Collaboratori della Pagina</h1>
        <div class="carousel">

            <div class="group">
                <?php foreach ($sponsorAttivi as $sponsor): ?>
                    <div class="card">
                        <img src="<?php echo htmlspecialchars($sponsor['logo']); ?>" alt="<?php echo htmlspecialchars($sponsor['nome']); ?>">
                    </div>
                <?php endforeach; ?>
            </div>

            <div aria-hidden class="group">
                <?php foreach ($sponsorAttivi as $sponsor): ?>
                    <div class="card">
                        <img src="<?php echo htmlspecialchars($sponsor['logo']); ?>" alt="<?php echo htmlspecialchars($sponsor['nome']); ?>">
                    </div>
                <?php endforeach; ?>
            </div>

            <div aria-hidden class="group">
                <?php foreach ($sponsorAttivi as $sponsor): ?>
                    <div class="card">
                        <img src="<?php echo htmlspecialchars($sponsor['logo']); ?>" alt="<?php echo htmlspecialchars($sponsor['nome']); ?>">
                    </div>
                <?php endforeach; ?>
            </div>

        </div>
    </section>

    <!-- virtuaTeam -->

    <section class="virtualTeam" id="virtualTeam">
        <h1>Passione Motorsport Racing Team</h1>

        <h2>
            Il Team Virtuale è il cuore digitale di Passione Motorsport: una community di quasi 40 persone che vive il
            <br>
            motorsport attraverso il sim racing. Organizziamo gare online, campionati interni e serate a tema, in un
            <br>
            ambiente competitivo ma soprattutto divertente, aperto a chi ama guidare — dal principiante al pilota già
            <br>
            esperto sul simulatore.
        </h2>
        <div class="roadmap">
            <div class="roadmap-item">
                <p class="roadmap-title">numeri della community</p>
                <div class="roadmap-stats">
                    <div><span class="num">40+</span><span class="lbl">membri attivi</span></div>
                    <div><span class="num">10+</span><span class="lbl">gare organizzate</span></div>
                    <div><span class="num">1</span><span class="lbl">campionato stagionale</span></div>
                    <div><span class="num">5+</span><span class="lbl">anni di attività</span></div>
                </div>
            </div>

            <div class="roadmap-item right">
                <p class="roadmap-title">cosa facciamo</p>
                <ul class="roadmap-list">
                    <li>Gare online mensili</li>
                    <li>Campionati con classifica stagionale</li>
                    <li>Supporto ai nuovi piloti</li>
                </ul>
            </div>

            <div class="roadmap-item">
                <p class="roadmap-title">come partecipare</p>
                <ol class="roadmap-steps">
                    <li>Segui la Pagina su Istagram / Facebook</li>
                    <li>Iscriviti al campionato o alla gara</li>
                    <li>Partecipa alle gare con il simulatore supportato</li>
                </ol>
            </div>

            <div class="roadmap-item right">
                <p class="roadmap-title">format delle gare</p>
                <div class="roadmap-badges">
                    <span>E-Rally Completo</span>
                    <span>E-Ronde</span>
                    <span>Campionati a punti</span>
                </div>
            </div>

            <div class="roadmap-item">
                <p class="roadmap-title">regole</p>
                <p class="roadmap-text">Fair play, guida pulita e rispetto degli altri piloti. Regolamento completo
                    disponibile al link della gara</p>
            </div>
        </div>

    </section>

    <!-- contatti -->

    <section class="contatti" id="contatti">
        <div class="spacing send">
            <h2>Scrivici qui sotto se hai qualche domanda</h2>
            <form method="POST" action="php/invia_contatto.php">
                <input type="text" class="text" id="nome" placeholder="il tuo nome" name="nome" required>
                <input type="email" class="email" id="email" placeholder="email" name="email" required>

                <select class="text" id="motivo" name="motivo" required>
                    <option value="generico">Motivo Messaggio</option>
                    <option value="generico">messaggio generico</option>
                    <option value="candidatura">candidatura Pilota</option>
                    <option value="sponsor">proposta di sponsorizzazione</option>
                </select>

                <input type="text" class="text" id="azienda" placeholder="nome azienda" name="azienda">

                <select class="text" id="reparto" name="reparto">
                    <option value="">reparto</option>
                    <option value="esports">esports</option>
                    <option value="reale">reale</option>
                </select>

                <input type="text" maxlength="150" class="text" id="text"
                    placeholder="Inserisci qui il contenuto del messaggio" name="messaggio" required>

                <button type="submit" class="submit" id="submit">Invia</button>
            </form>
        </div>

        <div class="spacing social">
            <h3>Seguici sui nostri social per rimanere aggiornato</h3>
            <div class="social-links">
                <a href="https://www.tiktok.com/@passione__motorsport?lang=it-IT" target="_blank" class="tiktok">
                    <svg viewBox="0 0 24 24" fill="currentColor">
                        <path
                            d="M14 3c.3 2 1.7 3.4 3.7 3.6v2.6c-1.3 0-2.6-.4-3.7-1.1v6.2a5.3 5.3 0 1 1-5.3-5.3c.3 0 .6 0 .9.1v2.7a2.6 2.6 0 1 0 1.8 2.5V3H14z" />
                    </svg>
                    <span>TikTok</span>
                </a>
                <a href="https://www.instagram.com/passione.motorsport/" target="_blank" class="instagram">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <rect x="3" y="3" width="18" height="18" rx="5" />
                        <circle cx="12" cy="12" r="4" />
                        <circle cx="17.5" cy="6.5" r="1" fill="currentColor" stroke="none" />
                    </svg>
                    <span>Instagram Principale</span>
                </a>
                <a href="https://www.facebook.com/passione.motorsport?ref=bookmarks&utm_source=ig&utm_medium=social&utm_content=link_in_bio#" target="_blank" class="facebook">
                    <svg viewBox="0 0 24 24" fill="currentColor">
                        <path
                            d="M13.5 21v-8h2.7l.4-3.2h-3.1V7.7c0-.9.3-1.6 1.6-1.6h1.7V3.2C16.5 3.1 15.4 3 14.2 3c-2.7 0-4.5 1.6-4.5 4.6v2.2H7v3.2h2.7V21h3.8z" />
                    </svg>
                    <span>Facebook</span>
                </a>
                <a href="https://www.instagram.com/passionemotorsport.racing.team/" target="_blank" class="instagramTeam">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <rect x="3" y="3" width="18" height="18" rx="5" />
                        <circle cx="12" cy="12" r="4" />
                        <circle cx="17.5" cy="6.5" r="1" fill="currentColor" stroke="none" />
                    </svg>
                    <span>Instagram Team Racing</span>
                </a>
                <a href="https://www.youtube.com/channel/UCURehetgEiVayIQEv9OdQtg" target="_blank" class="youtube">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <rect x="2" y="5" width="20" height="14" rx="4" />
                        <path d="M10 9.5l5 2.5-5 2.5v-5z" fill="currentColor" stroke="none" />
                    </svg>
                    <span>Youtube</span>
                </a>
            </div>
        </div>
    </section>


    <!-- Accesso Vip -->

    <section class="PremiumAccess" id="PremiumAccess">
        <h5>Collegamento Accesso Per gli utenti del team</h5>
        <a href="pages/TeamPage.php" class="PremiumAccessButton" target="_blank">Vai alla pagina</a>
    </section>

    <!-- footer -->

    <footer>
        <div class="footer-logo">Passione Motorsport Racing Team</div>
        <div class="footer-copy">Passione Motorsport Racing Team © 2026 — TUTTI I DIRITTI RISERVATI</div>
    </footer>

    <script src="js/admin-storage.js"></script>
    <script src="js/services/news.js"></script>
    <script src="js/services/contatti_open.js"></script>
    <script src="js/utils/navbarSwitch.js"></script>
    <script src="js/services/navbar.js"></script>
    <script src="js/index.js"></script>

</body>

</html>